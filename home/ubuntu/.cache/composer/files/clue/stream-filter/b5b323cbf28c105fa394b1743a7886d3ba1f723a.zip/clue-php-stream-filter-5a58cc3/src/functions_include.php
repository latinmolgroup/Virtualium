<?php

if (!function_exists('Clue\\StreamFilter\\append')) {
    require __DIR__ . '/functions.php';
}
