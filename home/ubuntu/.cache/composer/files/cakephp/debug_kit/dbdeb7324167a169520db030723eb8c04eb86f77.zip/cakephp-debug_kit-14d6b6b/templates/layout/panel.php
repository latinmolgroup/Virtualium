<?php
/**
 * @var \DebugKit\View\AjaxView $this
 */

echo $this->fetch('content');
