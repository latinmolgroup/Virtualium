<h4>Templates</h4>
<?= $this->Toolbar->makeNeatArray($templates) ?>
