Extending Bake
##############

.. note::
    La documentación no es compatible actualmente con el idioma español en esta página.

    Por favor, siéntase libre de enviarnos un pull request en
    `Github <https://github.com/cakephp/bake>`_ o utilizar el botón **Improve this Doc** para proponer directamente los cambios.

    Usted puede hacer referencia a la versión en Inglés en el menú de selección superior
    para obtener información sobre el tema de esta página.

.. _creating-a-bake-theme:

.. meta::
    :title lang=es: Extending Bake
    :keywords lang=es: command line interface,development,bake view, bake template syntax,erb tags,asp tags,percent tags
