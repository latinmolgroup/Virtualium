# Reporting a vulnerability

If you have found any issues that might have security implications,
please send a report privately to j.boggiano@seld.be

Do not report security reports publicly.
