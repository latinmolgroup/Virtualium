<?php

namespace Http\Message;

/**
 * An interface implemented by all HTTP message related exceptions.
 */
interface Exception
{
}
